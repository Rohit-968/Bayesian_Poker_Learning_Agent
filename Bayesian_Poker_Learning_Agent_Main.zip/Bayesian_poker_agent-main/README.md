# Bayesian Poker Agent

A high-performance, Bayesian inference–driven poker agent for Heads-Up No-Limit Texas Hold’em.  
This project combines a robust Python engine, probabilistic decision-making, and an interactive "glass-box" web interface that exposes the AI’s reasoning in real time.

---

## Overview

Traditional poker AIs rely on computationally intensive methods such as Counterfactual Regret Minimization (CFR) and large game trees.

This project adopts a different approach:

**Bayesian Inference + Hand Bucketing → Fast, Interpretable, and Efficient Decision-Making**

By compressing millions of possible game states into structured probability distributions, the agent:
- Operates in real time  
- Remains mathematically grounded  
- Provides full transparency into its decisions  

The agent dynamically computes Expected Value (EV) for every action, adapting continuously based on its belief about the opponent’s hidden cards.

---

## Key Features

### Bayesian "Glass Box" AI
- Fully interpretable decision-making  
- No black-box neural networks  
- Uses human-readable hand buckets such as:
  - Premium  
  - Strong Draw  
  - Weak Pair  
  - Air  

---

### Interactive Web Interface
- Built with Flask  
- Play against the AI in real time  
- Visualize:
  - Opponent belief distributions  
  - EV calculations  
  - Decision logic  

---

### Entropy-Guided Exploration
- Uses Shannon Entropy to quantify uncertainty  
- Strategy adapts dynamically:
  - High entropy → exploration and bluffing  
  - Low entropy → pure EV maximization  

---

### Modular and Extensible Design
Supports easy extension for:
- New opponent models  
- Reinforcement learning modules  
- Alternative evaluation strategies  

---

## System Architecture

The project follows a structured Sense → Think → Act pipeline:

### 1. Game Engine (`engine/`)
- Implements Texas Hold’em rules  
- Tracks:
  - Pot size  
  - Board state  
  - Legal actions  

---

### 2. Belief Module (`belief/`)
- Updates opponent hand distribution using Bayes’ Theorem  
- Inputs:
  - Observed opponent actions  
- Outputs:
  - Probability distribution over hand buckets  

---

### 3. Decision Engine (`decision/`, `evaluation/`)
- Runs Monte Carlo simulations  
- Computes:
  - Win equity  
  - Expected Value (EV) for:
    - Fold  
    - Call  
    - Bet/Raise  

---

### 4. Web Interface (`app.py`, `static/`)
- Displays:
  - Internal AI reasoning  
  - Probabilities  
  - Action evaluations  

---

## Getting Started

### Prerequisites
- Python 3.8+
- Flask
- Matplotlib

---

### Installation

```bash
git clone https://github.com/yourusername/bayesian_poker_agent.git
cd bayesian_poker_agent
pip install flask matplotlib
```

---

### Usage

#### 1. Play Against the AI (Web Interface)

```bash
python app.py
```

Open in browser:
```
http://localhost:5000
```

---

#### 2. Run Headless Simulations

```bash
python main.py
```

Outputs include:
- Mean chip gain  
- Confidence intervals  
- Multi-seed evaluation metrics  

---

## Agent Types

### Random Agent
- Baseline agent  
- Chooses actions uniformly at random  

---

### EV Agent
- Plays standard “ABC poker”  
- Assumes opponent has a uniform random range  
- Strong baseline but exploitable  

---

### Bayesian Agent
- Updates opponent beliefs dynamically  
- Computes EV against refined ranges  
- Capable of:
  - Exploitative play  
  - High-confidence folds  
  - Strategic bluffs  

---

## Sample Results

Bayesian Agent vs EV Agent (1,500 hands):

```
Mean chip gain: 4.4714  
95% CI: [3.2955, 5.6473]
```

### Interpretation
- Confidence interval lies entirely above 0  
- Indicates statistically significant outperformance  
- Demonstrates effective opponent exploitation  

---

## Future Improvements

### Reinforcement Learning Opponent Modeling
- Replace static likelihood tables  
- Learn opponent tendencies dynamically  

---

### Deep RL for Multi-Street Planning
- Current limitation: one-step EV optimization  
- Proposed: integrate Proximal Policy Optimization (PPO)  
- Enables:
  - Multi-street bluffing  
  - Strategic bet sizing  

---

### Unsupervised Hand Bucketing
- Replace heuristic buckets with clustering (e.g., K-Means)  
- Group hands by:
  - Equity  
  - Playability  

---

## Contributing

Contributions are welcome.

- Open issues for bugs or feature requests  
- Submit pull requests for improvements  
- Discuss ideas for new agent designs  

---

## License

This project is licensed under the MIT License.  
See the LICENSE file for details.
